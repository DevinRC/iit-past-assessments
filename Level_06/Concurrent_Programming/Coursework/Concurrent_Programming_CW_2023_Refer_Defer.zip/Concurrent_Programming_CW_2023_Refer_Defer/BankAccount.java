/** *********************************************************************
 * 6SENG006W Concurrent Programming  
 * File:      BankAccount.java  [interface]	
 * Author:    P. Howells	
 * Contents:  Company Banking System
 *            This provides the interface for a Bank Account class.
 * Date:      12/6/23
 ************************************************************************ */

public interface BankAccount
{
    int    getBalance( ) ;           // returns the current balance

    int    getAccountNumber( ) ;     // returns the Account number

    String getAccountHolder( ) ;     // returns the Account holder


    void deposit( Transaction t ) ;         // perform a deposit transaction on the bank account

    void withdrawal( Transaction t ) ;      // perform a withdrawal transaction on the bank account

    boolean directDebit( Transaction t ) ;  // perform a Direct Debit withdrawal transaction on the bank account,
                                            // if sufficient funds then it updates balance & returns true 
                                            // else if insufficient funds then it does not alter balance & returns false 


    void printStatement( ) ;         // prints out the transactions performed so far
}
